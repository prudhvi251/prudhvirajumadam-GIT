package Git;

public class Gitupload {

	
	
	public static void main(String args[])
	{
		System.out.println("First project uploaded to github using git");
	}
}
